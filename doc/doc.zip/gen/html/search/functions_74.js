var searchData=
[
  ['takeback',['TakeBack',['../classesnlib_1_1_buffer_manager.html#a6a246892d529f18c97fa748900d72e0e',1,'esnlib::BufferManager::TakeBack()'],['../classesnlib_1_1_io_buffer_manager.html#af5c29d946a6c9a94afd9947edf7b6598',1,'esnlib::IoBufferManager::TakeBack(BufferPtr buf)=0'],['../classesnlib_1_1_io_buffer_manager.html#a55541302c4f3e441aefe37e752269ef1',1,'esnlib::IoBufferManager::TakeBack(IoBufferPtr buf)=0'],['../classesnlib_1_1_session.html#aa5ae67133d71111fb61d7392e82d07c8',1,'esnlib::Session::TakeBack(boost::shared_ptr&lt; IoBuffer &gt; buf)=0'],['../classesnlib_1_1_session.html#a06a95e2b1d103f01b22491f365d94711',1,'esnlib::Session::TakeBack(boost::shared_ptr&lt; Buffer &gt; buf)=0']]],
  ['testidle',['TestIdle',['../classesnlib_1_1_session.html#a64c31b62b68aa126ef4bebb4ef5c8045',1,'esnlib::Session']]],
  ['trace',['Trace',['../classesnlib_1_1_logger.html#af77681885b91b54b42c9e412fe2eb440',1,'esnlib::Logger::Trace()'],['../classesnlib_1_1_log_manager.html#a284d66a41aff0b31219176a6a5e7f1c4',1,'esnlib::LogManager::Trace()']]],
  ['trimstr',['TrimStr',['../classesnlib_1_1_string_handler.html#a1e88498dc17d2c97d6c1830ddc7e7580',1,'esnlib::StringHandler']]],
  ['type',['type',['../classesnlib_1_1_io_buffer.html#a4cfd9ff0aa0febcc6aa47187ccf31f55',1,'esnlib::IoBuffer::type() const '],['../classesnlib_1_1_io_buffer.html#a95cb5da8d70350c511abaec0a092eb8c',1,'esnlib::IoBuffer::type(int value)']]]
];
